const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');
const fs = require('fs');

// Ensure db initialization
require('./db/database');

const { requireAuthPage } = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

// Body parser and cookies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Serve static uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Serve static assets (CSS, JS, images)
app.use(express.static(path.join(__dirname, 'public')));

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/employees', require('./routes/employees'));
app.use('/api/tasks', require('./routes/tasks'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/support', require('./routes/support'));
app.use('/api/settings', require('./routes/settings'));

// -------------------------------------------------------------
// MULTI-PAGE WEBSITE ROUTES (Every feature has its own distinct page)
// -------------------------------------------------------------

// 1. Home Page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 2. About Page
app.get('/about', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

// 3. Register Page
app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

// 4. Login Page
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// 5. Forgot Password Page
app.get('/forgot-password', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'forgot-password.html'));
});

// 6. Admin Dashboard Page
app.get('/admin/dashboard', requireAuthPage('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-dashboard.html'));
});

// 7. Employee Dashboard Page
app.get('/employee/dashboard', requireAuthPage('employee'), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'employee-dashboard.html'));
});

// 8. Manage Employees Page
app.get('/admin/employees', requireAuthPage('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-employees.html'));
});

// 9. Add Employee Page
app.get('/admin/add-employee', requireAuthPage('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-add-employee.html'));
});

// 10. Employee Profile Page
app.get('/profile', requireAuthPage(), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'profile.html'));
});

// 11. Create Task Page
app.get('/admin/create-task', requireAuthPage('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-create-task.html'));
});

// 12. Manage Tasks Page
app.get('/admin/tasks', requireAuthPage('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-tasks.html'));
});

// 13. Assign Task Page
app.get('/admin/assign-task', requireAuthPage('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-assign-task.html'));
});

// 14. My Tasks Page
app.get('/employee/tasks', requireAuthPage('employee'), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'employee-tasks.html'));
});

// 15. Task Details Page
app.get('/task-details', requireAuthPage(), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'task-details.html'));
});

// 16. Task Calendar Page
app.get('/calendar', requireAuthPage(), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'calendar.html'));
});

// 17. Notifications Page
app.get('/notifications', requireAuthPage(), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'notifications.html'));
});

// 18. Reports and Analytics Page
app.get('/admin/reports', requireAuthPage('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-reports.html'));
});

// 19. Settings Page
app.get('/settings', requireAuthPage(), (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'settings.html'));
});

// 20. Help and Support Page
app.get('/support', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'support.html'));
});

// 21. Logout Route
app.get('/logout', (req, res) => {
  res.clearCookie('token');
  res.redirect('/login?logout=1');
});

// 404 Handler for undefined routes
app.use((req, res) => {
  res.status(404).send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>404 - Page Not Found | ETMS</title>
      <link rel="stylesheet" href="/css/styles.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    </head>
    <body class="bg-light d-flex align-items-center justify-content-center" style="min-height: 100vh; font-family: 'Inter', sans-serif;">
      <div class="card p-5 text-center shadow-sm" style="max-width: 480px; border-radius: 12px;">
        <i class="fa-solid fa-triangle-exclamation text-primary mb-3" style="font-size: 3rem;"></i>
        <h2 class="mb-2">Page Not Found</h2>
        <p class="text-muted mb-4">The page you requested does not exist or has been moved.</p>
        <a href="/" class="btn btn-primary"><i class="fa-solid fa-house me-2"></i>Return to Home</a>
      </div>
    </body>
    </html>
  `);
});

app.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`Employee Task Management System (ETMS) running at:`);
  console.log(`http://localhost:${PORT}`);
  console.log(`Default Administrator: admin@company.com / Admin@12345`);
  console.log(`=======================================================`);
});

module.exports = app;

