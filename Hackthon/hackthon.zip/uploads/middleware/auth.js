const jwt = require('jsonwebtoken');
const db = require('../db/database');

const JWT_SECRET = process.env.JWT_SECRET || 'etms-secure-jwt-key-2026-prod-secret';

function getUserFromToken(req) {
  let token = null;
  if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  } else if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) return null;

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = db.prepare(`
      SELECT id, employee_id, full_name, email, phone, department, designation, role, status, joining_date, avatar_color, created_at
      FROM users WHERE id = ?
    `).get(decoded.id);

    if (!user || user.status !== 'Active') {
      return null;
    }
    return user;
  } catch (err) {
    return null;
  }
}

// API Middleware: Require authenticated user
function authenticateApi(req, res, next) {
  const user = getUserFromToken(req);
  if (!user) {
    return res.status(401).json({ success: false, message: 'Authentication required. Please login.' });
  }
  req.user = user;
  next();
}

// API Middleware: Require specific role (e.g. 'admin' or 'employee')
function requireRoleApi(roles) {
  const allowed = Array.isArray(roles) ? roles : [roles];
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Authentication required.' });
    }
    if (!allowed.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Access denied. You do not have permission for this action.' });
    }
    next();
  };
}

// Page Route Middleware: Protect HTML pages
function requireAuthPage(role = null) {
  return (req, res, next) => {
    const user = getUserFromToken(req);
    if (!user) {
      return res.redirect(`/login?redirect=${encodeURIComponent(req.originalUrl)}`);
    }
    if (role && user.role !== role) {
      // If wrong role, redirect to their corresponding dashboard
      if (user.role === 'admin') {
        return res.redirect('/admin/dashboard');
      } else {
        return res.redirect('/employee/dashboard');
      }
    }
    req.user = user;
    next();
  };
}

module.exports = {
  JWT_SECRET,
  getUserFromToken,
  authenticateApi,
  requireRoleApi,
  requireAuthPage
};

