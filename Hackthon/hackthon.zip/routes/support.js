const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { authenticateApi, requireRoleApi, getUserFromToken } = require('../middleware/auth');

// POST /api/support - Submit support ticket
router.post('/', (req, res) => {
  try {
    const { name, email, employee_id, category, subject, description } = req.body;

    if (!name || !email || !category || !subject || !description) {
      return res.status(400).json({ success: false, message: 'Please fill in all required fields.' });
    }

    const currentUser = getUserFromToken(req);
    const userId = currentUser ? currentUser.id : null;

    // Generate ticket number: SUP-2001, etc.
    const lastTicket = db.prepare('SELECT id FROM support_requests ORDER BY id DESC LIMIT 1').get();
    const nextNum = (lastTicket ? lastTicket.id : 0) + 2001;
    const ticketNumber = `SUP-${nextNum}`;

    const insert = db.prepare(`
      INSERT INTO support_requests (ticket_number, user_id, full_name, email, employee_id, category, subject, description, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Open')
    `);

    insert.run(
      ticketNumber,
      userId,
      name.trim(),
      email.trim(),
      employee_id ? employee_id.trim() : (currentUser ? currentUser.employee_id : ''),
      category,
      subject.trim(),
      description.trim()
    );

    // If logged in, create notification
    if (userId) {
      db.prepare(`
        INSERT INTO notifications (user_id, title, message, type, link)
        VALUES (?, ?, ?, 'info', ?)
      `).run(
        userId,
        `Support Ticket Created: ${ticketNumber}`,
        `Your request regarding "${subject.trim()}" has been received. Our support team will review it.`,
        '/support'
      );
    }

    res.status(201).json({
      success: true,
      message: 'Support request submitted successfully! Your ticket ID is ' + ticketNumber,
      ticketNumber
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to submit support request: ' + err.message });
  }
});

// GET /api/support/my-tickets - List current user tickets
router.get('/my-tickets', authenticateApi, (req, res) => {
  try {
    const tickets = db.prepare(`
      SELECT id, ticket_number, category, subject, description, status, admin_notes, created_at
      FROM support_requests
      WHERE user_id = ? OR LOWER(email) = LOWER(?)
      ORDER BY created_at DESC
    `).all(req.user.id, req.user.email);

    res.json({ success: true, tickets });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/support/all - List all tickets (Admin only)
router.get('/all', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const tickets = db.prepare(`
      SELECT id, ticket_number, user_id, full_name, email, employee_id, category, subject, description, status, admin_notes, created_at
      FROM support_requests
      ORDER BY created_at DESC
    `).all();

    res.json({ success: true, tickets });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PATCH /api/support/:id/status - Update ticket status (Admin only)
router.patch('/:id/status', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { status, admin_notes } = req.body;

    const ticket = db.prepare('SELECT * FROM support_requests WHERE id = ?').get(id);
    if (!ticket) {
      return res.status(404).json({ success: false, message: 'Ticket not found.' });
    }

    db.prepare(`
      UPDATE support_requests
      SET status = COALESCE(?, status), admin_notes = COALESCE(?, admin_notes)
      WHERE id = ?
    `).run(status || null, admin_notes || null, id);

    if (ticket.user_id) {
      db.prepare(`
        INSERT INTO notifications (user_id, title, message, type, link)
        VALUES (?, ?, ?, 'info', ?)
      `).run(
        ticket.user_id,
        `Ticket Updated: ${ticket.ticket_number}`,
        `Your support request status has been updated to "${status}".`,
        '/support'
      );
    }

    res.json({ success: true, message: 'Ticket updated successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;

