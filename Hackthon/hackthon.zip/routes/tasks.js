const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('../db/database');
const { authenticateApi, requireRoleApi } = require('../middleware/auth');

// Setup multer for attachments
const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const safeName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
    cb(null, uniqueSuffix + '-' + safeName);
  }
});
const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// Helper: Calculate overdue
function computeOverdue(task) {
  const isOverdue = task.status !== 'Completed' && task.due_date && new Date(task.due_date + 'T23:59:59') < new Date();
  return {
    ...task,
    is_overdue: isOverdue,
    display_status: isOverdue && task.status !== 'Completed' ? 'Overdue' : task.status
  };
}

// GET /api/tasks - Retrieve tasks with search and filters
router.get('/', authenticateApi, (req, res) => {
  try {
    const {
      search = '',
      status = '',
      priority = '',
      department = '',
      employee_id = '',
      sort = 'due_date_asc'
    } = req.query;

    let query = `
      SELECT 
        t.id, t.task_code, t.title, t.description, t.department,
        t.start_date, t.due_date, t.priority, t.status, t.progress,
        t.completed_at, t.created_at, t.updated_at,
        u.id as assigned_to_id, u.full_name as assigned_to_name, u.employee_id as assigned_to_emp_id, u.avatar_color as assigned_to_color,
        creator.full_name as created_by_name
      FROM tasks t
      LEFT JOIN users u ON t.assigned_to = u.id
      LEFT JOIN users creator ON t.created_by = creator.id
      WHERE 1=1
    `;
    const params = [];

    // Role-based access control: Employees only see their own tasks!
    if (req.user.role === 'employee') {
      query += ` AND t.assigned_to = ?`;
      params.push(req.user.id);
    } else if (employee_id && employee_id !== 'All') {
      query += ` AND t.assigned_to = ?`;
      params.push(parseInt(employee_id, 10));
    }

    if (search) {
      query += ` AND (LOWER(t.title) LIKE ? OR LOWER(t.description) LIKE ? OR UPPER(t.task_code) LIKE ? OR LOWER(u.full_name) LIKE ?)`;
      const s = `%${search.toLowerCase()}%`;
      const sUpper = `%${search.toUpperCase()}%`;
      params.push(s, s, sUpper, s);
    }

    if (status && status !== 'All') {
      if (status === 'Overdue') {
        query += ` AND t.status != 'Completed' AND t.due_date < date('now', 'localtime')`;
      } else {
        query += ` AND t.status = ?`;
        params.push(status);
      }
    }

    if (priority && priority !== 'All') {
      query += ` AND t.priority = ?`;
      params.push(priority);
    }

    if (department && department !== 'All') {
      query += ` AND t.department = ?`;
      params.push(department);
    }

    // Sort order
    if (sort === 'due_date_asc') {
      query += ` ORDER BY t.due_date ASC`;
    } else if (sort === 'due_date_desc') {
      query += ` ORDER BY t.due_date DESC`;
    } else if (sort === 'priority') {
      query += ` ORDER BY CASE t.priority WHEN 'Urgent' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 WHEN 'Low' THEN 4 ELSE 5 END`;
    } else if (sort === 'title') {
      query += ` ORDER BY t.title ASC`;
    } else {
      query += ` ORDER BY t.created_at DESC`;
    }

    const rows = db.prepare(query).all(...params);
    const tasks = rows.map(computeOverdue);

    res.json({ success: true, count: tasks.length, tasks });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to retrieve tasks: ' + err.message });
  }
});

// GET /api/tasks/calendar-events - Retrieve tasks for calendar view
router.get('/calendar-events', authenticateApi, (req, res) => {
  try {
    let query = `
      SELECT t.id, t.task_code, t.title, t.start_date, t.due_date, t.priority, t.status, t.progress,
             u.full_name as assigned_to_name
      FROM tasks t
      LEFT JOIN users u ON t.assigned_to = u.id
      WHERE 1=1
    `;
    const params = [];

    if (req.user.role === 'employee') {
      query += ` AND t.assigned_to = ?`;
      params.push(req.user.id);
    }

    const rows = db.prepare(query).all(...params);
    const events = rows.map(t => {
      const isOverdue = t.status !== 'Completed' && t.due_date && new Date(t.due_date + 'T23:59:59') < new Date();
      return {
        id: t.id,
        code: t.task_code,
        title: t.title,
        startDate: t.start_date,
        dueDate: t.due_date,
        priority: t.priority,
        status: t.status,
        progress: t.progress,
        assignedTo: t.assigned_to_name,
        isOverdue
      };
    });

    res.json({ success: true, events });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/tasks/:id - Retrieve single task details
router.get('/:id', authenticateApi, (req, res) => {
  try {
    const taskId = parseInt(req.params.id, 10);
    const task = db.prepare(`
      SELECT 
        t.id, t.task_code, t.title, t.description, t.department,
        t.start_date, t.due_date, t.priority, t.status, t.progress,
        t.completed_at, t.created_at, t.updated_at,
        u.id as assigned_to_id, u.full_name as assigned_to_name, u.employee_id as assigned_to_emp_id,
        u.email as assigned_to_email, u.department as assigned_to_dept, u.avatar_color as assigned_to_color,
        creator.id as created_by_id, creator.full_name as created_by_name
      FROM tasks t
      LEFT JOIN users u ON t.assigned_to = u.id
      LEFT JOIN users creator ON t.created_by = creator.id
      WHERE t.id = ?
    `).get(taskId);

    if (!task) {
      return res.status(404).json({ success: false, message: 'Task not found.' });
    }

    // Role check: Employee can only view their own assigned task
    if (req.user.role === 'employee' && task.assigned_to_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied. You can only view tasks assigned to you.' });
    }

    // Get comments
    const comments = db.prepare(`
      SELECT c.id, c.comment, c.created_at, u.id as user_id, u.full_name, u.role, u.avatar_color
      FROM task_comments c
      JOIN users u ON c.user_id = u.id
      WHERE c.task_id = ?
      ORDER BY c.created_at ASC
    `).all(taskId);

    // Get attachments
    const attachments = db.prepare(`
      SELECT a.id, a.file_name, a.file_path, a.file_size, a.created_at, u.full_name as uploaded_by_name
      FROM task_attachments a
      JOIN users u ON a.uploaded_by = u.id
      WHERE a.task_id = ?
      ORDER BY a.created_at DESC
    `).all(taskId);

    // Get history
    const history = db.prepare(`
      SELECT h.id, h.action, h.details, h.created_at, u.full_name as user_name
      FROM task_history h
      JOIN users u ON h.user_id = u.id
      WHERE h.task_id = ?
      ORDER BY h.created_at DESC
    `).all(taskId);

    res.json({
      success: true,
      task: computeOverdue(task),
      comments,
      attachments,
      history
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to load task details: ' + err.message });
  }
});

// POST /api/tasks - Create new task (Admin only)
router.post('/', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const {
      title,
      description,
      department,
      assigned_to,
      start_date,
      due_date,
      priority = 'Medium',
      initial_status = 'Pending'
    } = req.body;

    if (!title || !due_date || !assigned_to) {
      return res.status(400).json({ success: false, message: 'Please provide task title, assigned employee, and due date.' });
    }

    // Verify assigned employee exists and is active
    const employee = db.prepare('SELECT id, full_name, email FROM users WHERE id = ?').get(assigned_to);
    if (!employee) {
      return res.status(400).json({ success: false, message: 'Assigned employee was not found.' });
    }

    // Generate unique task code: TSK-1001, etc.
    const lastTask = db.prepare('SELECT id FROM tasks ORDER BY id DESC LIMIT 1').get();
    const nextNum = (lastTask ? lastTask.id : 0) + 1001;
    const taskCode = `TSK-${nextNum}`;

    const startDate = start_date || new Date().toISOString().split('T')[0];

    const insert = db.prepare(`
      INSERT INTO tasks (task_code, title, description, department, assigned_to, created_by, start_date, due_date, priority, status, progress)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = insert.run(
      taskCode,
      title.trim(),
      description ? description.trim() : '',
      department || 'General',
      parseInt(assigned_to, 10),
      req.user.id,
      startDate,
      due_date,
      priority,
      initial_status,
      initial_status === 'In Progress' ? 25 : 0
    );

    const newTaskId = result.lastInsertRowid;

    // Log history
    db.prepare(`
      INSERT INTO task_history (task_id, user_id, action, details)
      VALUES (?, ?, ?, ?)
    `).run(
      newTaskId,
      req.user.id,
      'Created Task',
      `Task created and assigned to ${employee.full_name} with priority ${priority} and due date ${due_date}.`
    );

    // Create notification for employee
    db.prepare(`
      INSERT INTO notifications (user_id, title, message, type, link)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      employee.id,
      `New Task Assigned: ${taskCode}`,
      `You have been assigned task "${title.trim()}". Priority: ${priority}. Due date: ${due_date}.`,
      'task',
      `/task-details?id=${newTaskId}`
    );

    res.status(201).json({
      success: true,
      message: `Task ${taskCode} created and assigned to ${employee.full_name}.`,
      taskId: newTaskId,
      taskCode
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to create task: ' + err.message });
  }
});

// PUT /api/tasks/:id - Update task details (Admin only)
router.put('/:id', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const taskId = parseInt(req.params.id, 10);
    const { title, description, department, priority, due_date, start_date, assigned_to } = req.body;

    const existing = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Task not found.' });
    }

    const update = db.prepare(`
      UPDATE tasks SET
        title = COALESCE(?, title),
        description = COALESCE(?, description),
        department = COALESCE(?, department),
        priority = COALESCE(?, priority),
        due_date = COALESCE(?, due_date),
        start_date = COALESCE(?, start_date),
        assigned_to = COALESCE(?, assigned_to),
        updated_at = datetime('now', 'localtime')
      WHERE id = ?
    `);

    update.run(
      title ? title.trim() : null,
      description !== undefined ? description.trim() : null,
      department || null,
      priority || null,
      due_date || null,
      start_date || null,
      assigned_to ? parseInt(assigned_to, 10) : null,
      taskId
    );

    // If assigned employee changed, send notification and history
    if (assigned_to && parseInt(assigned_to, 10) !== existing.assigned_to) {
      const newEmp = db.prepare('SELECT full_name FROM users WHERE id = ?').get(parseInt(assigned_to, 10));
      db.prepare(`
        INSERT INTO task_history (task_id, user_id, action, details)
        VALUES (?, ?, 'Reassigned Task', ?)
      `).run(taskId, req.user.id, `Task reassigned to ${newEmp ? newEmp.full_name : 'new employee'}.`);

      db.prepare(`
        INSERT INTO notifications (user_id, title, message, type, link)
        VALUES (?, ?, ?, 'task', ?)
      `).run(
        parseInt(assigned_to, 10),
        `Task Reassigned: ${existing.task_code}`,
        `You have been assigned to task "${existing.title}".`,
        `/task-details?id=${taskId}`
      );
    } else {
      db.prepare(`
        INSERT INTO task_history (task_id, user_id, action, details)
        VALUES (?, ?, 'Updated Task', ?)
      `).run(taskId, req.user.id, 'Task details were updated by admin.');
    }

    res.json({ success: true, message: 'Task updated successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update task: ' + err.message });
  }
});

// POST /api/tasks/:id/assign - Reassign Task (Admin only)
router.post('/:id/assign', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const taskId = parseInt(req.params.id, 10);
    const { assigned_to, notes } = req.body;

    if (!assigned_to) {
      return res.status(400).json({ success: false, message: 'Please select an employee to assign this task.' });
    }

    const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
    if (!task) {
      return res.status(404).json({ success: false, message: 'Task not found.' });
    }

    const employee = db.prepare('SELECT id, full_name FROM users WHERE id = ?').get(parseInt(assigned_to, 10));
    if (!employee) {
      return res.status(404).json({ success: false, message: 'Selected employee not found.' });
    }

    db.prepare(`
      UPDATE tasks SET assigned_to = ?, updated_at = datetime('now', 'localtime') WHERE id = ?
    `).run(employee.id, taskId);

    const historyDetails = notes
      ? `Reassigned to ${employee.full_name}. Notes: ${notes}`
      : `Reassigned to ${employee.full_name}.`;

    db.prepare(`
      INSERT INTO task_history (task_id, user_id, action, details)
      VALUES (?, ?, 'Reassigned', ?)
    `).run(taskId, req.user.id, historyDetails);

    // Notify employee
    db.prepare(`
      INSERT INTO notifications (user_id, title, message, type, link)
      VALUES (?, ?, ?, 'task', ?)
    `).run(
      employee.id,
      `Task Assigned to You: ${task.task_code}`,
      `Task "${task.title}" has been assigned to you. Due date: ${task.due_date}.`,
      `/task-details?id=${taskId}`
    );

    res.json({
      success: true,
      message: `Task ${task.task_code} has been successfully assigned to ${employee.full_name}.`
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PATCH /api/tasks/:id/status - Update task status (Admin or Assigned Employee)
router.patch('/:id/status', authenticateApi, (req, res) => {
  try {
    const taskId = parseInt(req.params.id, 10);
    const { status, progress, comment } = req.body;

    if (!status || !['Pending', 'In Progress', 'Completed'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Valid status required (Pending, In Progress, or Completed).' });
    }

    const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
    if (!task) {
      return res.status(404).json({ success: false, message: 'Task not found.' });
    }

    // Role check: Employee can only update their own task
    if (req.user.role === 'employee' && task.assigned_to !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied. You can only update tasks assigned to you.' });
    }

    let newProgress = progress !== undefined ? parseInt(progress, 10) : task.progress;
    let completedAt = task.completed_at;

    if (status === 'Completed') {
      newProgress = 100;
      completedAt = new Date().toISOString();
    } else if (status === 'In Progress' && newProgress === 0) {
      newProgress = 25;
      completedAt = null;
    } else if (status === 'Pending') {
      newProgress = 0;
      completedAt = null;
    }

    db.prepare(`
      UPDATE tasks 
      SET status = ?, progress = ?, completed_at = ?, updated_at = datetime('now', 'localtime')
      WHERE id = ?
    `).run(status, newProgress, completedAt, taskId);

    // Record in history
    db.prepare(`
      INSERT INTO task_history (task_id, user_id, action, details)
      VALUES (?, ?, 'Status Changed', ?)
    `).run(
      taskId,
      req.user.id,
      `Status changed from "${task.status}" to "${status}" (Progress: ${newProgress}%).`
    );

    // Optional comment
    if (comment && comment.trim()) {
      db.prepare(`
        INSERT INTO task_comments (task_id, user_id, comment)
        VALUES (?, ?, ?)
      `).run(taskId, req.user.id, comment.trim());
    }

    // Send notification: If employee updated status, notify admin(s)
    if (req.user.role === 'employee') {
      const admins = db.prepare("SELECT id FROM users WHERE role = 'admin'").all();
      for (const admin of admins) {
        db.prepare(`
          INSERT INTO notifications (user_id, title, message, type, link)
          VALUES (?, ?, ?, 'task', ?)
        `).run(
          admin.id,
          `Task Status Update: ${task.task_code}`,
          `${req.user.full_name} updated task "${task.title}" to "${status}".`,
          `/task-details?id=${taskId}`
        );
      }
    } else if (task.assigned_to && task.assigned_to !== req.user.id) {
      // If admin updated status, notify employee
      db.prepare(`
        INSERT INTO notifications (user_id, title, message, type, link)
        VALUES (?, ?, ?, 'task', ?)
      `).run(
        task.assigned_to,
        `Task Status Update: ${task.task_code}`,
        `Administrator updated your task "${task.title}" to "${status}".`,
        `/task-details?id=${taskId}`
      );
    }

    res.json({
      success: true,
      message: `Task status updated to "${status}".`,
      status,
      progress: newProgress
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update status: ' + err.message });
  }
});

// POST /api/tasks/:id/comments - Add comment (Admin or Assigned Employee)
router.post('/:id/comments', authenticateApi, (req, res) => {
  try {
    const taskId = parseInt(req.params.id, 10);
    const { comment } = req.body;

    if (!comment || !comment.trim()) {
      return res.status(400).json({ success: false, message: 'Comment text cannot be empty.' });
    }

    const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
    if (!task) {
      return res.status(404).json({ success: false, message: 'Task not found.' });
    }

    if (req.user.role === 'employee' && task.assigned_to !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    const insert = db.prepare(`
      INSERT INTO task_comments (task_id, user_id, comment)
      VALUES (?, ?, ?)
    `);
    const result = insert.run(taskId, req.user.id, comment.trim());

    // History
    db.prepare(`
      INSERT INTO task_history (task_id, user_id, action, details)
      VALUES (?, ?, 'Added Comment', ?)
    `).run(taskId, req.user.id, `${req.user.full_name} posted a comment.`);

    // Notification to counterpart
    if (req.user.role === 'employee' && task.created_by) {
      db.prepare(`
        INSERT INTO notifications (user_id, title, message, type, link)
        VALUES (?, ?, ?, 'info', ?)
      `).run(
        task.created_by,
        `New Comment on ${task.task_code}`,
        `${req.user.full_name} commented on task "${task.title}".`,
        `/task-details?id=${taskId}`
      );
    } else if (req.user.role === 'admin' && task.assigned_to) {
      db.prepare(`
        INSERT INTO notifications (user_id, title, message, type, link)
        VALUES (?, ?, ?, 'info', ?)
      `).run(
        task.assigned_to,
        `New Comment on ${task.task_code}`,
        `Admin commented on your task "${task.title}".`,
        `/task-details?id=${taskId}`
      );
    }

    res.status(201).json({
      success: true,
      message: 'Comment added successfully.',
      commentId: result.lastInsertRowid
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/tasks/:id/attachments - Upload attachment
router.post('/:id/attachments', authenticateApi, upload.single('attachment'), (req, res) => {
  try {
    const taskId = parseInt(req.params.id, 10);
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No file was uploaded.' });
    }

    const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
    if (!task) {
      // Remove uploaded file if task does not exist
      fs.unlinkSync(req.file.path);
      return res.status(404).json({ success: false, message: 'Task not found.' });
    }

    if (req.user.role === 'employee' && task.assigned_to !== req.user.id) {
      fs.unlinkSync(req.file.path);
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    const relativePath = `/uploads/${req.file.filename}`;
    const insert = db.prepare(`
      INSERT INTO task_attachments (task_id, uploaded_by, file_name, file_path, file_size)
      VALUES (?, ?, ?, ?, ?)
    `);
    const result = insert.run(
      taskId,
      req.user.id,
      req.file.originalname,
      relativePath,
      req.file.size
    );

    // History
    db.prepare(`
      INSERT INTO task_history (task_id, user_id, action, details)
      VALUES (?, ?, 'Uploaded Attachment', ?)
    `).run(taskId, req.user.id, `Uploaded file "${req.file.originalname}" (${(req.file.size / 1024).toFixed(1)} KB).`);

    res.status(201).json({
      success: true,
      message: 'Attachment uploaded successfully.',
      attachmentId: result.lastInsertRowid,
      file: {
        name: req.file.originalname,
        path: relativePath,
        size: req.file.size
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to upload attachment: ' + err.message });
  }
});

// DELETE /api/tasks/:id - Delete task (Admin only)
router.delete('/:id', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const taskId = parseInt(req.params.id, 10);
    const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
    if (!task) {
      return res.status(404).json({ success: false, message: 'Task not found.' });
    }

    // Clean up attachment files from disk
    const attachments = db.prepare('SELECT file_path FROM task_attachments WHERE task_id = ?').all(taskId);
    for (const att of attachments) {
      const fullPath = path.join(__dirname, '..', att.file_path);
      if (fs.existsSync(fullPath)) {
        try { fs.unlinkSync(fullPath); } catch (e) {}
      }
    }

    db.prepare('DELETE FROM tasks WHERE id = ?').run(taskId);

    res.json({
      success: true,
      message: `Task ${task.task_code} has been deleted successfully.`
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete task: ' + err.message });
  }
});

module.exports = router;

