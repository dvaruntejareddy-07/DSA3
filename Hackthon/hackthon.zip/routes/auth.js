const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db/database');
const { JWT_SECRET, authenticateApi } = require('../middleware/auth');

// Available colors for avatar badges
const AVATAR_COLORS = ['#2563eb', '#059669', '#d97706', '#dc2626', '#7c3aed', '#0891b2', '#4f46e5'];

// GET /api/auth/departments - list departments for dropdowns
router.get('/departments', (req, res) => {
  try {
    const depts = db.prepare('SELECT id, name, description FROM departments ORDER BY name ASC').all();
    res.json({ success: true, departments: depts });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch departments: ' + err.message });
  }
});

// POST /api/auth/register
router.post('/register', (req, res) => {
  try {
    const {
      full_name,
      employee_id,
      email,
      phone,
      department,
      designation,
      password,
      confirm_password,
      role = 'employee',
      admin_secret
    } = req.body;

    // Validation
    if (!full_name || !employee_id || !email || !department || !password) {
      return res.status(400).json({ success: false, message: 'Please fill in all required fields.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long.' });
    }

    if (confirm_password && password !== confirm_password) {
      return res.status(400).json({ success: false, message: 'Passwords do not match.' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ success: false, message: 'Please provide a valid email address.' });
    }

    const trimmedEmpId = employee_id.trim().toUpperCase();
    const trimmedEmail = email.trim().toLowerCase();

    // Check duplicate employee_id
    const existingEmpId = db.prepare('SELECT id FROM users WHERE UPPER(employee_id) = ?').get(trimmedEmpId);
    if (existingEmpId) {
      return res.status(400).json({ success: false, message: `Employee ID "${trimmedEmpId}" is already registered. Please choose another.` });
    }

    // Check duplicate email
    const existingEmail = db.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(trimmedEmail);
    if (existingEmail) {
      return res.status(400).json({ success: false, message: `Email "${trimmedEmail}" is already registered. Please login instead.` });
    }

    // Security check: Role
    let assignedRole = 'employee';
    if (role === 'admin') {
      const ADMIN_SECRET = process.env.ADMIN_REGISTRATION_SECRET || 'ETMS-ADMIN-2026';
      if (!admin_secret || admin_secret.trim() !== ADMIN_SECRET) {
        return res.status(403).json({
          success: false,
          message: 'Admin authorization code is invalid. Unauthorized registration as Administrator is not permitted.'
        });
      }
      assignedRole = 'admin';
    }

    const salt = bcrypt.genSaltSync(10);
    const password_hash = bcrypt.hashSync(password, salt);
    const today = new Date().toISOString().split('T')[0];
    const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

    const insertStmt = db.prepare(`
      INSERT INTO users (employee_id, full_name, email, phone, department, designation, role, password_hash, status, joining_date, avatar_color)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Active', ?, ?)
    `);

    const result = insertStmt.run(
      trimmedEmpId,
      full_name.trim(),
      trimmedEmail,
      phone ? phone.trim() : '',
      department,
      designation ? designation.trim() : (assignedRole === 'admin' ? 'Administrator' : 'Team Member'),
      assignedRole,
      password_hash,
      today,
      color
    );

    const newUserId = result.lastInsertRowid;

    // Create user settings
    db.prepare('INSERT INTO user_settings (user_id) VALUES (?)').run(newUserId);

    // Initial welcome notification
    db.prepare(`
      INSERT INTO notifications (user_id, title, message, type, link)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      newUserId,
      'Welcome to Employee Task Management System',
      `Welcome ${full_name}! Your account (${trimmedEmpId}) has been successfully created. Explore your dashboard to get started.`,
      'success',
      assignedRole === 'admin' ? '/admin/dashboard' : '/employee/dashboard'
    );

    // Generate JWT token
    const token = jwt.sign(
      { id: newUserId, role: assignedRole, employee_id: trimmedEmpId },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.cookie('token', token, {
      httpOnly: true,
      maxAge: 7 * 24 * 60 * 60 * 1000,
      sameSite: 'lax'
    });

    const redirectUrl = assignedRole === 'admin' ? '/admin/dashboard' : '/employee/dashboard';

    res.status(201).json({
      success: true,
      message: 'Registration successful! Redirecting to your dashboard...',
      redirectUrl,
      token,
      user: {
        id: newUserId,
        employee_id: trimmedEmpId,
        full_name: full_name.trim(),
        email: trimmedEmail,
        department,
        designation: designation || (assignedRole === 'admin' ? 'Administrator' : 'Team Member'),
        role: assignedRole
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error during registration: ' + err.message });
  }
});

// POST /api/auth/login
router.post('/login', (req, res) => {
  try {
    const { login_id, password, role_hint } = req.body;

    if (!login_id || !password) {
      return res.status(400).json({ success: false, message: 'Please provide both Employee ID / Email and Password.' });
    }

    const trimmedLogin = login_id.trim();

    // Lookup user by email or employee_id
    const user = db.prepare(`
      SELECT * FROM users
      WHERE LOWER(email) = LOWER(?) OR UPPER(employee_id) = UPPER(?)
    `).get(trimmedLogin, trimmedLogin);

    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid credentials. User not found.' });
    }

    if (user.status !== 'Active') {
      return res.status(403).json({ success: false, message: 'Your account has been deactivated. Please contact your administrator.' });
    }

    const isMatch = bcrypt.compareSync(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid credentials. Incorrect password.' });
    }

    // Role check if specific role was explicitly selected in login tab
    if (role_hint && role_hint !== user.role) {
      return res.status(403).json({
        success: false,
        message: `This account is registered as an ${user.role.toUpperCase()}, not an ${role_hint.toUpperCase()}. Please select the ${user.role.toUpperCase()} tab.`
      });
    }

    // Sign JWT
    const token = jwt.sign(
      { id: user.id, role: user.role, employee_id: user.employee_id },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.cookie('token', token, {
      httpOnly: true,
      maxAge: 7 * 24 * 60 * 60 * 1000,
      sameSite: 'lax'
    });

    const redirectUrl = user.role === 'admin' ? '/admin/dashboard' : '/employee/dashboard';

    res.json({
      success: true,
      message: 'Login successful! Redirecting...',
      redirectUrl,
      token,
      user: {
        id: user.id,
        employee_id: user.employee_id,
        full_name: user.full_name,
        email: user.email,
        phone: user.phone,
        department: user.department,
        designation: user.designation,
        role: user.role,
        joining_date: user.joining_date,
        avatar_color: user.avatar_color
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error during login: ' + err.message });
  }
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ success: true, message: 'Logged out successfully.' });
});

// GET /api/auth/me
router.get('/me', authenticateApi, (req, res) => {
  try {
    const unreadNotifications = db.prepare(`
      SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0
    `).get(req.user.id).count;

    res.json({
      success: true,
      user: req.user,
      unreadNotifications
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/auth/forgot-password
router.post('/forgot-password', (req, res) => {
  try {
    const { email_or_id, new_password, confirm_password } = req.body;

    if (!email_or_id) {
      return res.status(400).json({ success: false, message: 'Please provide your registered Email or Employee ID.' });
    }

    const trimmed = email_or_id.trim();
    const user = db.prepare(`
      SELECT id, full_name, email, employee_id FROM users
      WHERE LOWER(email) = LOWER(?) OR UPPER(employee_id) = UPPER(?)
    `).get(trimmed, trimmed);

    if (!user) {
      return res.status(404).json({ success: false, message: 'No registered account found with that Email or Employee ID.' });
    }

    if (!new_password) {
      // Just step 1: account verification
      return res.json({
        success: true,
        message: `Account verified for ${user.full_name} (${user.employee_id}). Please enter your new password.`,
        verified: true,
        userId: user.id
      });
    }

    // Step 2: update password
    if (new_password.length < 6) {
      return res.status(400).json({ success: false, message: 'New password must be at least 6 characters.' });
    }
    if (new_password !== confirm_password) {
      return res.status(400).json({ success: false, message: 'Passwords do not match.' });
    }

    const salt = bcrypt.genSaltSync(10);
    const password_hash = bcrypt.hashSync(new_password, salt);

    db.prepare('UPDATE users SET password_hash = ?, updated_at = datetime("now", "localtime") WHERE id = ?').run(password_hash, user.id);

    // Notify user
    db.prepare(`
      INSERT INTO notifications (user_id, title, message, type, link)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      user.id,
      'Password Reset Successful',
      'Your account password was updated successfully. If this was not you, contact an administrator immediately.',
      'warning',
      '/settings'
    );

    res.json({
      success: true,
      message: 'Password reset successful! You can now log in with your new password.'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error processing password reset: ' + err.message });
  }
});

module.exports = router;

