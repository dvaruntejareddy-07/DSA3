const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db/database');
const { authenticateApi, requireRoleApi } = require('../middleware/auth');

// Available colors for avatar badges
const AVATAR_COLORS = ['#2563eb', '#059669', '#d97706', '#dc2626', '#7c3aed', '#0891b2', '#4f46e5'];

// GET /api/employees - list employees with search & filters and task statistics
router.get('/', authenticateApi, (req, res) => {
  try {
    const { search = '', department = '', status = '', role = '' } = req.query;

    let query = `
      SELECT 
        u.id, u.employee_id, u.full_name, u.email, u.phone, u.department, u.designation,
        u.role, u.status, u.joining_date, u.avatar_color, u.created_at,
        COUNT(t.id) as total_tasks,
        SUM(CASE WHEN t.status = 'Pending' THEN 1 ELSE 0 END) as pending_tasks,
        SUM(CASE WHEN t.status = 'In Progress' THEN 1 ELSE 0 END) as in_progress_tasks,
        SUM(CASE WHEN t.status = 'Completed' THEN 1 ELSE 0 END) as completed_tasks,
        SUM(CASE WHEN t.status != 'Completed' AND t.due_date < date('now', 'localtime') THEN 1 ELSE 0 END) as overdue_tasks
      FROM users u
      LEFT JOIN tasks t ON u.id = t.assigned_to
      WHERE 1=1
    `;
    const params = [];

    if (search) {
      query += ` AND (LOWER(u.full_name) LIKE ? OR LOWER(u.email) LIKE ? OR UPPER(u.employee_id) LIKE ? OR LOWER(u.designation) LIKE ?)`;
      const s = `%${search.toLowerCase()}%`;
      const sUpper = `%${search.toUpperCase()}%`;
      params.push(s, s, sUpper, s);
    }

    if (department && department !== 'All') {
      query += ` AND u.department = ?`;
      params.push(department);
    }

    if (status && status !== 'All') {
      query += ` AND u.status = ?`;
      params.push(status);
    }

    if (role && role !== 'All') {
      query += ` AND u.role = ?`;
      params.push(role);
    }

    query += ` GROUP BY u.id ORDER BY u.created_at DESC`;

    const employees = db.prepare(query).all(...params);

    res.json({ success: true, count: employees.length, employees });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to retrieve employees: ' + err.message });
  }
});

// GET /api/employees/:id - get single employee profile
router.get('/:id', authenticateApi, (req, res) => {
  try {
    const employeeId = parseInt(req.params.id, 10);
    const user = db.prepare(`
      SELECT id, employee_id, full_name, email, phone, department, designation, role, status, joining_date, avatar_color, created_at
      FROM users WHERE id = ?
    `).get(employeeId);

    if (!user) {
      return res.status(404).json({ success: false, message: 'Employee not found.' });
    }

    // Get employee tasks
    const tasks = db.prepare(`
      SELECT id, task_code, title, priority, status, progress, start_date, due_date, created_at
      FROM tasks WHERE assigned_to = ?
      ORDER BY due_date ASC
    `).all(employeeId);

    // Compute stats
    const stats = {
      total: tasks.length,
      pending: tasks.filter(t => t.status === 'Pending').length,
      in_progress: tasks.filter(t => t.status === 'In Progress').length,
      completed: tasks.filter(t => t.status === 'Completed').length,
      overdue: tasks.filter(t => t.status !== 'Completed' && new Date(t.due_date) < new Date()).length
    };

    res.json({ success: true, employee: user, stats, tasks });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/employees - Add new employee (Admin only)
router.post('/', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const {
      employee_id,
      full_name,
      email,
      phone,
      department,
      designation,
      joining_date,
      password,
      role = 'employee',
      status = 'Active'
    } = req.body;

    if (!employee_id || !full_name || !email || !department || !password) {
      return res.status(400).json({ success: false, message: 'Missing required employee fields.' });
    }

    const trimmedEmpId = employee_id.trim().toUpperCase();
    const trimmedEmail = email.trim().toLowerCase();

    // Check duplicate employee_id
    const existingEmp = db.prepare('SELECT id FROM users WHERE UPPER(employee_id) = ?').get(trimmedEmpId);
    if (existingEmp) {
      return res.status(400).json({ success: false, message: `Employee ID "${trimmedEmpId}" already exists.` });
    }

    // Check duplicate email
    const existingEmail = db.prepare('SELECT id FROM users WHERE LOWER(email) = ?').get(trimmedEmail);
    if (existingEmail) {
      return res.status(400).json({ success: false, message: `Email "${trimmedEmail}" already exists.` });
    }

    const salt = bcrypt.genSaltSync(10);
    const password_hash = bcrypt.hashSync(password, salt);
    const joinDate = joining_date || new Date().toISOString().split('T')[0];
    const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

    const insert = db.prepare(`
      INSERT INTO users (employee_id, full_name, email, phone, department, designation, role, password_hash, status, joining_date, avatar_color)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = insert.run(
      trimmedEmpId,
      full_name.trim(),
      trimmedEmail,
      phone ? phone.trim() : '',
      department,
      designation ? designation.trim() : (role === 'admin' ? 'Administrator' : 'Specialist'),
      role,
      password_hash,
      status,
      joinDate,
      color
    );

    const newUserId = result.lastInsertRowid;
    db.prepare('INSERT INTO user_settings (user_id) VALUES (?)').run(newUserId);

    // Initial welcome notification
    db.prepare(`
      INSERT INTO notifications (user_id, title, message, type, link)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      newUserId,
      'Welcome to the Team!',
      `Your account (${trimmedEmpId}) has been configured by the administration team.`,
      'success',
      '/employee/dashboard'
    );

    res.status(201).json({
      success: true,
      message: `Employee "${full_name}" (${trimmedEmpId}) added successfully.`,
      employeeId: newUserId
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to add employee: ' + err.message });
  }
});

// PUT /api/employees/:id - Update employee details (Admin only)
router.put('/:id', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const targetId = parseInt(req.params.id, 10);
    const { full_name, email, phone, department, designation, role, status, joining_date } = req.body;

    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(targetId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Employee not found.' });
    }

    if (email && email.trim().toLowerCase() !== existing.email.toLowerCase()) {
      const emailTaken = db.prepare('SELECT id FROM users WHERE LOWER(email) = ? AND id != ?').get(email.trim().toLowerCase(), targetId);
      if (emailTaken) {
        return res.status(400).json({ success: false, message: `Email "${email}" is already used by another user.` });
      }
    }

    // Prevent admin from deactivating or demoting themselves
    if (req.user.id === targetId) {
      if (status === 'Inactive') {
        return res.status(400).json({ success: false, message: 'You cannot deactivate your own administrative account.' });
      }
      if (role && role !== 'admin') {
        return res.status(400).json({ success: false, message: 'You cannot remove your own admin privileges.' });
      }
    }

    const update = db.prepare(`
      UPDATE users SET
        full_name = COALESCE(?, full_name),
        email = COALESCE(?, email),
        phone = COALESCE(?, phone),
        department = COALESCE(?, department),
        designation = COALESCE(?, designation),
        role = COALESCE(?, role),
        status = COALESCE(?, status),
        joining_date = COALESCE(?, joining_date),
        updated_at = datetime('now', 'localtime')
      WHERE id = ?
    `);

    update.run(
      full_name ? full_name.trim() : null,
      email ? email.trim().toLowerCase() : null,
      phone !== undefined ? phone.trim() : null,
      department || null,
      designation !== undefined ? designation.trim() : null,
      role || null,
      status || null,
      joining_date || null,
      targetId
    );

    res.json({ success: true, message: 'Employee details updated successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update employee: ' + err.message });
  }
});

// PATCH /api/employees/:id/toggle-status - Activate / Deactivate (Admin only)
router.patch('/:id/toggle-status', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const targetId = parseInt(req.params.id, 10);
    if (req.user.id === targetId) {
      return res.status(400).json({ success: false, message: 'You cannot toggle the status of your own account.' });
    }

    const user = db.prepare('SELECT id, full_name, status FROM users WHERE id = ?').get(targetId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'Employee not found.' });
    }

    const newStatus = user.status === 'Active' ? 'Inactive' : 'Active';
    db.prepare("UPDATE users SET status = ?, updated_at = datetime('now', 'localtime') WHERE id = ?").run(newStatus, targetId);

    res.json({
      success: true,
      message: `Employee "${user.full_name}" is now ${newStatus}.`,
      status: newStatus
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/employees/:id - Delete employee (Admin only)
router.delete('/:id', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const targetId = parseInt(req.params.id, 10);
    if (req.user.id === targetId) {
      return res.status(400).json({ success: false, message: 'You cannot delete your own administrative account.' });
    }

    const user = db.prepare('SELECT id, full_name, employee_id FROM users WHERE id = ?').get(targetId);
    if (!user) {
      return res.status(404).json({ success: false, message: 'Employee not found.' });
    }

    // Reassign assigned tasks to unassigned / NULL before deleting
    db.prepare('UPDATE tasks SET assigned_to = NULL WHERE assigned_to = ?').run(targetId);
    // Delete user (cascade removes settings, notifications, comments)
    db.prepare('DELETE FROM users WHERE id = ?').run(targetId);

    res.json({
      success: true,
      message: `Employee "${user.full_name}" (${user.employee_id}) has been removed successfully.`
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete employee: ' + err.message });
  }
});

module.exports = router;

