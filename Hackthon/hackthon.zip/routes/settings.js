const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db/database');
const { authenticateApi } = require('../middleware/auth');

// GET /api/settings - Retrieve profile & preferences
router.get('/', authenticateApi, (req, res) => {
  try {
    const user = db.prepare(`
      SELECT id, employee_id, full_name, email, phone, department, designation, role, status, joining_date, avatar_color, created_at
      FROM users WHERE id = ?
    `).get(req.user.id);

    let prefs = db.prepare('SELECT * FROM user_settings WHERE user_id = ?').get(req.user.id);
    if (!prefs) {
      db.prepare('INSERT INTO user_settings (user_id) VALUES (?)').run(req.user.id);
      prefs = { email_notifications: 1, deadline_reminders: 1, task_assignment_alerts: 1, theme: 'light' };
    }

    res.json({ success: true, profile: user, preferences: prefs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/settings/profile - Update personal profile
router.put('/profile', authenticateApi, (req, res) => {
  try {
    const { full_name, phone, designation } = req.body;

    if (!full_name || !full_name.trim()) {
      return res.status(400).json({ success: false, message: 'Full name cannot be empty.' });
    }

    db.prepare(`
      UPDATE users SET
        full_name = ?,
        phone = ?,
        designation = ?,
        updated_at = datetime('now', 'localtime')
      WHERE id = ?
    `).run(
      full_name.trim(),
      phone ? phone.trim() : '',
      designation ? designation.trim() : req.user.designation,
      req.user.id
    );

    res.json({ success: true, message: 'Profile updated successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update profile: ' + err.message });
  }
});

// PUT /api/settings/password - Change password
router.put('/password', authenticateApi, (req, res) => {
  try {
    const { current_password, new_password, confirm_password } = req.body;

    if (!current_password || !new_password) {
      return res.status(400).json({ success: false, message: 'Please provide current and new passwords.' });
    }

    if (new_password.length < 6) {
      return res.status(400).json({ success: false, message: 'New password must be at least 6 characters.' });
    }

    if (new_password !== confirm_password) {
      return res.status(400).json({ success: false, message: 'New passwords do not match.' });
    }

    const user = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(req.user.id);
    const isMatch = bcrypt.compareSync(current_password, user.password_hash);
    if (!isMatch) {
      return res.status(400).json({ success: false, message: 'Current password is incorrect.' });
    }

    const salt = bcrypt.genSaltSync(10);
    const newHash = bcrypt.hashSync(new_password, salt);

    db.prepare('UPDATE users SET password_hash = ?, updated_at = datetime("now", "localtime") WHERE id = ?').run(newHash, req.user.id);

    // Notification
    db.prepare(`
      INSERT INTO notifications (user_id, title, message, type, link)
      VALUES (?, 'Security Notice', 'Your account password has been changed successfully.', 'warning', '/settings')
    `).run(req.user.id);

    res.json({ success: true, message: 'Password changed successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to change password: ' + err.message });
  }
});

// PUT /api/settings/preferences - Update notification & theme preferences
router.put('/preferences', authenticateApi, (req, res) => {
  try {
    const { email_notifications, deadline_reminders, task_assignment_alerts, theme } = req.body;

    db.prepare(`
      INSERT INTO user_settings (user_id, email_notifications, deadline_reminders, task_assignment_alerts, theme)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET
        email_notifications = excluded.email_notifications,
        deadline_reminders = excluded.deadline_reminders,
        task_assignment_alerts = excluded.task_assignment_alerts,
        theme = excluded.theme
    `).run(
      req.user.id,
      email_notifications ? 1 : 0,
      deadline_reminders ? 1 : 0,
      task_assignment_alerts ? 1 : 0,
      theme || 'light'
    );

    res.json({ success: true, message: 'Preferences saved successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;

