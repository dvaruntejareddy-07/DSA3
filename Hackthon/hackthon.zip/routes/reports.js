const express = require('express');
const router = express.Router();
const db = require('../db/database');
const { authenticateApi, requireRoleApi } = require('../middleware/auth');

// GET /api/reports/summary - Overview stats
router.get('/summary', authenticateApi, (req, res) => {
  try {
    const isEmployee = req.user.role === 'employee';
    let baseWhere = isEmployee ? 'WHERE assigned_to = ' + req.user.id : '';

    const totalTasks = db.prepare(`SELECT COUNT(*) as count FROM tasks ${baseWhere}`).get().count;
    const completedTasks = db.prepare(`SELECT COUNT(*) as count FROM tasks ${baseWhere ? baseWhere + ' AND' : 'WHERE'} status = 'Completed'`).get().count;
    const inProgressTasks = db.prepare(`SELECT COUNT(*) as count FROM tasks ${baseWhere ? baseWhere + ' AND' : 'WHERE'} status = 'In Progress'`).get().count;
    const pendingTasks = db.prepare(`SELECT COUNT(*) as count FROM tasks ${baseWhere ? baseWhere + ' AND' : 'WHERE'} status = 'Pending'`).get().count;
    const overdueTasks = db.prepare(`
      SELECT COUNT(*) as count FROM tasks 
      ${baseWhere ? baseWhere + ' AND' : 'WHERE'} status != 'Completed' AND due_date < date('now', 'localtime')
    `).get().count;

    const totalEmployees = db.prepare("SELECT COUNT(*) as count FROM users WHERE role = 'employee' AND status = 'Active'").get().count;

    const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

    res.json({
      success: true,
      summary: {
        totalTasks,
        completedTasks,
        inProgressTasks,
        pendingTasks,
        overdueTasks,
        totalEmployees,
        completionRate
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/reports/analytics - Detailed reports with filters (Admin only)
router.get('/analytics', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const { from_date, to_date, department } = req.query;

    let filterClause = 'WHERE 1=1';
    const params = [];

    if (from_date) {
      filterClause += ' AND t.start_date >= ?';
      params.push(from_date);
    }
    if (to_date) {
      filterClause += ' AND t.due_date <= ?';
      params.push(to_date);
    }
    if (department && department !== 'All') {
      filterClause += ' AND t.department = ?';
      params.push(department);
    }

    // 1. Overall Metrics in range
    const metrics = db.prepare(`
      SELECT 
        COUNT(t.id) as total,
        SUM(CASE WHEN t.status = 'Completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN t.status = 'In Progress' THEN 1 ELSE 0 END) as in_progress,
        SUM(CASE WHEN t.status = 'Pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN t.status != 'Completed' AND t.due_date < date('now', 'localtime') THEN 1 ELSE 0 END) as overdue
      FROM tasks t
      ${filterClause}
    `).get(...params);

    const total = metrics.total || 0;
    const completed = metrics.completed || 0;
    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0;

    // 2. Department Breakdown
    const deptBreakdown = db.prepare(`
      SELECT 
        COALESCE(t.department, 'General') as department,
        COUNT(t.id) as total_tasks,
        SUM(CASE WHEN t.status = 'Completed' THEN 1 ELSE 0 END) as completed_tasks,
        SUM(CASE WHEN t.status = 'In Progress' THEN 1 ELSE 0 END) as in_progress_tasks,
        SUM(CASE WHEN t.status = 'Pending' THEN 1 ELSE 0 END) as pending_tasks,
        SUM(CASE WHEN t.status != 'Completed' AND t.due_date < date('now', 'localtime') THEN 1 ELSE 0 END) as overdue_tasks
      FROM tasks t
      ${filterClause}
      GROUP BY t.department
      ORDER BY total_tasks DESC
    `).all(...params);

    // 3. Employee Performance
    const employeePerformance = db.prepare(`
      SELECT 
        u.id, u.employee_id, u.full_name, u.department, u.designation,
        COUNT(t.id) as assigned_tasks,
        SUM(CASE WHEN t.status = 'Completed' THEN 1 ELSE 0 END) as completed_tasks,
        SUM(CASE WHEN t.status = 'In Progress' THEN 1 ELSE 0 END) as in_progress_tasks,
        SUM(CASE WHEN t.status = 'Pending' THEN 1 ELSE 0 END) as pending_tasks,
        SUM(CASE WHEN t.status != 'Completed' AND t.due_date < date('now', 'localtime') THEN 1 ELSE 0 END) as overdue_tasks
      FROM users u
      LEFT JOIN tasks t ON u.id = t.assigned_to ${from_date ? 'AND t.start_date >= "' + from_date + '"' : ''} ${to_date ? 'AND t.due_date <= "' + to_date + '"' : ''}
      WHERE u.role = 'employee' AND u.status = 'Active' ${department && department !== 'All' ? 'AND u.department = "' + department + '"' : ''}
      GROUP BY u.id
      ORDER BY completed_tasks DESC, assigned_tasks DESC
    `).all();

    const formattedEmployees = employeePerformance.map(e => ({
      ...e,
      completion_rate: e.assigned_tasks > 0 ? Math.round((e.completed_tasks / e.assigned_tasks) * 100) : 0
    }));

    // 4. Priority breakdown
    const priorityBreakdown = db.prepare(`
      SELECT priority, COUNT(t.id) as count
      FROM tasks t
      ${filterClause}
      GROUP BY priority
    `).all(...params);

    // 5. Status breakdown
    const statusBreakdown = db.prepare(`
      SELECT status, COUNT(t.id) as count
      FROM tasks t
      ${filterClause}
      GROUP BY status
    `).all(...params);

    res.json({
      success: true,
      data: {
        summary: {
          total,
          completed,
          in_progress: metrics.in_progress || 0,
          pending: metrics.pending || 0,
          overdue: metrics.overdue || 0,
          completionRate
        },
        deptBreakdown,
        employeePerformance: formattedEmployees,
        priorityBreakdown,
        statusBreakdown
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Analytics query error: ' + err.message });
  }
});

// GET /api/reports/export-csv - Download real CSV report
router.get('/export-csv', authenticateApi, requireRoleApi('admin'), (req, res) => {
  try {
    const tasks = db.prepare(`
      SELECT 
        t.task_code, t.title, t.department,
        u.employee_id, u.full_name as assigned_to,
        t.priority, t.status, t.progress,
        t.start_date, t.due_date, t.completed_at
      FROM tasks t
      LEFT JOIN users u ON t.assigned_to = u.id
      ORDER BY t.created_at DESC
    `).all();

    const headers = ['Task Code', 'Title', 'Department', 'Employee ID', 'Assigned To', 'Priority', 'Status', 'Progress (%)', 'Start Date', 'Due Date', 'Completed Date'];
    const rows = tasks.map(t => [
      `"${t.task_code}"`,
      `"${(t.title || '').replace(/"/g, '""')}"`,
      `"${t.department || ''}"`,
      `"${t.employee_id || ''}"`,
      `"${(t.assigned_to || 'Unassigned').replace(/"/g, '""')}"`,
      `"${t.priority}"`,
      `"${t.status}"`,
      t.progress || 0,
      `"${t.start_date || ''}"`,
      `"${t.due_date || ''}"`,
      `"${t.completed_at || ''}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=etms-task-report-${new Date().toISOString().split('T')[0]}.csv`);
    res.send(csvContent);
  } catch (err) {
    res.status(500).json({ success: false, message: 'Export failed: ' + err.message });
  }
});

module.exports = router;

