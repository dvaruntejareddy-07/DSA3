/**
 * Employee Task Management System (ETMS)
 * Shared JavaScript Client Utilities
 */

let currentUser = null;

// Initialize common functionality when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  initToasts();
  initSidebarToggle();
  checkAuthAndPopulate();
});

// Toast system initialization
function initToasts() {
  if (!document.getElementById('toast-container')) {
    const container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
}

function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const icons = {
    success: 'fa-solid fa-circle-check',
    danger: 'fa-solid fa-circle-xmark',
    warning: 'fa-solid fa-triangle-exclamation',
    info: 'fa-solid fa-circle-info'
  };

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <i class="${icons[type] || icons.info} toast-icon"></i>
    <div class="toast-content">${message}</div>
    <button onclick="this.parentElement.remove()" style="background:none;border:none;color:#94a3b8;cursor:pointer;font-size:0.9rem;">
      <i class="fa-solid fa-xmark"></i>
    </button>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// Sidebar toggle for mobile devices
function initSidebarToggle() {
  const toggleBtn = document.getElementById('sidebarToggleBtn');
  const sidebar = document.querySelector('.app-sidebar');

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('sidebar-open');
    });

    // Close on outside click on mobile
    document.addEventListener('click', (e) => {
      if (window.innerWidth <= 992 && !sidebar.contains(e.target) && !toggleBtn.contains(e.target) && sidebar.classList.contains('sidebar-open')) {
        sidebar.classList.remove('sidebar-open');
      }
    });
  }
}

// Check current user authentication & populate header/sidebar
async function checkAuthAndPopulate() {
  // Only execute on internal app pages (pages with .app-container)
  if (!document.querySelector('.app-container')) return;

  try {
    const res = await fetch('/api/auth/me');
    if (res.status === 401) {
      window.location.href = `/login?redirect=${encodeURIComponent(window.location.pathname)}`;
      return;
    }

    const data = await res.json();
    if (data.success && data.user) {
      currentUser = data.user;
      renderUserInfo(data.user, data.unreadNotifications);
      highlightActiveNav();
    }
  } catch (err) {
    console.error('Failed to load user state:', err);
  }
}

function renderUserInfo(user, unreadCount = 0) {
  // Update sidebar user snippet
  const userNameEl = document.getElementById('sidebarUserName');
  const userRoleEl = document.getElementById('sidebarUserRole');
  const userAvatarEl = document.getElementById('sidebarUserAvatar');

  if (userNameEl) userNameEl.textContent = user.full_name;
  if (userRoleEl) userRoleEl.textContent = `${user.role.toUpperCase()} • ${user.department}`;
  if (userAvatarEl) {
    userAvatarEl.textContent = getInitials(user.full_name);
    if (user.avatar_color) userAvatarEl.style.backgroundColor = user.avatar_color;
  }

  // Update header notifications badge
  const notifBadge = document.getElementById('headerNotifBadge');
  if (notifBadge) {
    if (unreadCount > 0) {
      notifBadge.textContent = unreadCount > 99 ? '99+' : unreadCount;
      notifBadge.style.display = 'flex';
    } else {
      notifBadge.style.display = 'none';
    }
  }
}

function getInitials(name) {
  if (!name) return 'U';
  return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
}

function highlightActiveNav() {
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.sidebar-menu .nav-link');

  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPath || (href !== '/' && currentPath.startsWith(href))) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
}

// Modal management
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }
}

// Global Logout function
async function handleLogout() {
  if (!confirm('Are you sure you want to sign out?')) return;
  try {
    const res = await fetch('/api/auth/logout', { method: 'POST' });
    const data = await res.json();
    if (data.success) {
      window.location.href = '/login?logout=1';
    }
  } catch (err) {
    window.location.href = '/logout';
  }
}

// Common badge generators
function getPriorityBadge(priority) {
  const p = (priority || 'Medium').toLowerCase();
  return `<span class="badge badge-${p}"><i class="fa-solid fa-flag"></i> ${priority}</span>`;
}

function getStatusBadge(status, isOverdue = false) {
  if (isOverdue && status !== 'Completed') {
    return `<span class="badge badge-overdue"><i class="fa-solid fa-circle-exclamation"></i> Overdue</span>`;
  }
  const sClass = status === 'In Progress' ? 'in-progress' : status.toLowerCase();
  let icon = 'fa-clock';
  if (status === 'Completed') icon = 'fa-circle-check';
  if (status === 'In Progress') icon = 'fa-spinner fa-spin-pulse';

  return `<span class="badge badge-${sClass}"><i class="fa-solid ${icon}"></i> ${status}</span>`;
}

function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

